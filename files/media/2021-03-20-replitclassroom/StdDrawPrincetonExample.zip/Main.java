/* algs4.jar from https://algs4.cs.princeton.edu/code/algs4.jar 
   Assignment Reference: https://www.billmongan.com/Ursinus-CS173/Assignments/Faces
*/
import edu.princeton.cs.algs4.*;

class Main {
  public static void main(String[] args) {
    StdDraw.circle(0.5, 0.5, 0.5);
    StdDraw.arc(0.5, 0.5, 0.4, 180, 0); // smile
    StdDraw.circle(0.25, 0.75, 0.1); // eye
    StdDraw.circle(0.75, 0.75, 0.1); // eye
    StdDraw.circle(0.5, 0.5, 0.15); // nose
  }
}