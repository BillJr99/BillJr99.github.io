/* Click the checkmark on the left menu, and click the setup button to initialize your tests.  It will prompt you to add these imports.
*/
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;

/* Then, click "Add Test" under the same checkmark menu. 

   Add your test code, for example:

    Main tester = new Main();
    int result = tester.squareIt(-2);
    assertEquals(4, result);
  
  Finally, click Run Tests under the checkmark menu for a report.

   Reference: https://docs.repl.it/repls/UnitTesting*/

class Main {
  public static int doubleIt(int x) {
    return 2*x;
  }

  public static int squareIt(int x) {
    return x*x;
  }

  public static void main(String[] args) {
    System.out.println("Hello world!");

    int y = squareIt(5);
    System.out.println("5 squared is " + y);
  }
}