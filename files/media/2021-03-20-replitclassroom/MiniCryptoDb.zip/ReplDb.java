import java.net.*;
import java.util.*;
import java.io.*;

/* Add ReplDb.java to .replit run command to compile with the project */
class ReplDb {
  /* 
     repl.it key value datastore uses $REPL_DB_URL with GET requests:
     GET $REPL_DB_URL with data "key=value" to insert
     GET $REPL_DB_URL/key to get key
     DELETE $REPL_DB_URL/key to delete key

     verb is: GET, POST, DELETE, ...
     data is optional (can be null), key=value
     pathsuffix is optional (can be empty string), "/key"
     Reference: https://www.baeldung.com/java-http-request
  */
  public static String replitDBhttpRequest(String verb, String pathsuffix, String data, boolean response, boolean debug) {
    String result = "";

    try {
      Map<String, String> env = System.getenv();
      String path = env.get("REPLIT_DB_URL");

      if(debug) {
        System.out.println("Connecting to: " + path + pathsuffix + " with data: " + data);
      }

      URL url = new URL(path + pathsuffix);
      HttpURLConnection con = (HttpURLConnection) url.openConnection();
      con.setRequestMethod(verb);    

      if(data != null) {
        con.setDoOutput(true);
        DataOutputStream out = new DataOutputStream(con.getOutputStream());
        out.writeBytes(data);
        out.flush();
        out.close();      
      }

      if(response) {
        BufferedReader in = new BufferedReader(
          new InputStreamReader(con.getInputStream()));
        String inputLine;
        StringBuffer content = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
            content.append(inputLine);
        }
        in.close();    

        result = content.toString();
      }

      if(debug) {
        int status = con.getResponseCode();
        System.out.println("Got: " + status);
      }
    } catch(Exception e) {
      if(debug) {
        e.printStackTrace();
      }
    }

    return result;
  }

  public static void insertDb(String key, String value) {
    replitDBhttpRequest("GET", "", key + "=" + value, false, true);
  }

  public static String getDb(String key) {
    return replitDBhttpRequest("GET", "/" + key, null, true, true);
  }  

  public static void removeDb(String key) {
    replitDBhttpRequest("DELETE", "/" + key, null, false, true);
  }  
}