/* To import the rsamath.jar file, first upload it to this project.
   Create a .replit file and enter the following:

   run = "export CLASSPATH=\".:lib/rsamath.jar\"; javac -d . Main.java; java Main"

   This adds the jar to your classpath along with the current project directory, so that your Main.java can compile (in the main project directory) while also loading the library from the rsamath.jar file.  The remaining javac and java commands are the standard compilation and execution commands that replit would use by default.

   Reference: https://replit.com/talk/ask/Jar-files/21299

   Assignment Reference: https://www.billmongan.com/Ursinus-CS173/Assignments/MiniCrypto
 */
   
import cs4hs11.rsalibrary.RSAMath;
import java.util.Scanner;

class Main {
  public static void genKey(long A, long B) {
    long C = A * B;

    // this is also RSAMath.totient(C), but this is difficult to compute on a large value of C.  It's easy to generate if you know A and B, the prime factors of C.  Therein lies the secret behind RSA encryption!
    long M = (A-1) * (B-1); 

    long E = RSAMath.coprime(M);
    long D = RSAMath.mod_inverse(E, M);

    ReplDb.insertDb("E", Long.toString(E));    
    ReplDb.insertDb("D", Long.toString(D));
    ReplDb.insertDb("C", Long.toString(C));
  }

  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);

    String dbE = ReplDb.getDb("E");
    String dbD = ReplDb.getDb("D");
    String dbC = ReplDb.getDb("C");

    if(dbE.strip().length() == 0 || dbD.strip().length() == 0 || dbC.strip().length() == 0) {
      System.out.println("Enter two prime numbers A and B (2 to 3 digits each would be ideal!)");

      long A = input.nextLong();
      long B = input.nextLong();

      genKey(A, B);
      
      dbE = ReplDb.getDb("E");
      dbD = ReplDb.getDb("D");
      dbC = ReplDb.getDb("C");
    }

    long E = Long.valueOf(dbE);
    long D = Long.valueOf(dbD);
    long C = Long.valueOf(dbC);

    System.out.println("Your public key is: (" + E + ", " + C + ")");
    System.out.println("Your private key is: (" + D + ", " + C + ")");

    // Test the key
    System.out.println("Enter a character to encrypt");
    char x = input.next().charAt(0);

    long xval = (long) x;
    long encrypted = RSAMath.endecrypt(xval, E, C);
    long decrypted = RSAMath.endecrypt(encrypted, D, C);
    char decryptedChar = (char) decrypted;

    System.out.println(x + " is character " + xval + " in the ASCII table, which encrypts to " + encrypted);

    System.out.println(encrypted + " decrypts to " + decrypted + ", which, in the ASCII table, is the character " + decryptedChar);

    // Ask the user if they'd like to remove the saved key for next time
    System.out.println("Would you like to remove these keys from the database to re-generate them next time? (y/Y)");
    char remove = input.next().toLowerCase().charAt(0);
    if(remove == 'y') {
      ReplDb.removeDb("E");
      ReplDb.removeDb("D");
      ReplDb.removeDb("C");
    }
  }
}