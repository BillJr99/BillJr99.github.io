import edu.princeton.cs.algs4.StdDraw;

class Main {

    public static double getY(double x, double freq) {
        double y = (Math.sin(x * freq) + 1) / 2.0;
        return y;
    }
    
    public static void drawLine(int red, int green, int blue, double prevX, 
                                double prevY, double x, double y) {
        System.out.println("Drawing from (" + prevX + ", " + prevY + 
                           ") to (" + x + ", " + y + ")");

        StdDraw.setPenColor(red, green, blue);
        StdDraw.line(prevX, prevY, x, y);        
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int red = 100;
        int blue = 100;
        int green = 0;

        int diffRed = 0;
        int diffBlue = 100;
        int diffGreen = 100;
        
        double dx = 0.0005;
        double penRadius = 0.001;
        
        double freq = 8 * Math.PI;
                
        StdDraw.setPenRadius(penRadius);
        
        double x = 0;
        double y = getY(x, freq);
        double prevX = x;
        double prevY = y;
        
        double dy = y - prevY;
        double prevDy = 0;
        
        for(x = dx; x < 1; x = x + dx) {           
            y = getY(x, freq);
            
            dy = y - prevY; 
            
            double scaledPrevDy = 0.5 + prevDy / (freq * dx);
            double scaledDy = 0.5 + dy / (freq * dx);
            
            drawLine(red, green, blue, prevX, prevY, x, y);
            drawLine(diffRed, diffGreen, diffBlue, prevX, scaledPrevDy, x, scaledDy);
            
            prevX = x;
            prevY = y;
            
            prevDy = dy;
        }
    }
}